def importar_datos(datasheet):
    xfile1=open(datasheet,"r",encoding="utf-8")
    xfile1.seek(0)
    curso= xfile1.readline().split(",")[1]
    xfile1.readline()
    paralelo= xfile1.readline().split(",")[1]
    datos={}
    percent=False
    for i in xfile1:
        xlinea=i.strip().split(",")
        xtexto=xlinea[0]
        par="P"+paralelo.strip().split()[-1]
        if xtexto[0:5]=="Quest":
            n= xtexto.split()[-1]
            base={"Descripcion":xlinea[1],"Detalles":{}}
            info=datos.setdefault(n,base)
            if n =="7":
                percent=True
        if par in xtexto:
            equipo= xtexto.split("-")[-1]
            integrante=xlinea[1]
            if percent:
                promedio=xlinea[4] 
            else: 
                promedio=xlinea[-1]
            if promedio!="" and promedio[0].isdigit() :
                promedio=float(promedio)
                if percent: 
                    promedio=round(promedio*8/120,2)
                if equipo in info["Detalles"]: 
                    info["Detalles"][equipo][integrante]=promedio
                else:
                    info["Detalles"][equipo]={integrante:promedio}
    xfile1.close()
    estudiantes = []
    for pregunta in datos.keys():
        for equipo in datos[pregunta]["Detalles"].keys():
            for estudiante in datos[pregunta]["Detalles"][equipo].keys():
                if estudiante not in estudiantes:
                    estudiantes.append(estudiante)
    totalEstudiantes = len(estudiantes)
    return datos,paralelo,totalEstudiantes