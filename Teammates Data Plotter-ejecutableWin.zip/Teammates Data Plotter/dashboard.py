from numpy import array
from PyQt5.QtWidgets import QApplication, QFileDialog, QHBoxLayout, QMainWindow, QAbstractScrollArea, QDialog, QMessageBox, QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem, QWidget
from PyQt5.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QIcon, QPixmap, QBrush ,QColor, QCursor
from PyQt5.uic import loadUi
from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg as FigureCanvas)
import db
from os import getcwd
from seaborn import catplot,relplot,set_style
import matplotlib.pyplot as plt
from main import HomeWindow

set_style("darkgrid")

class InfoDialog(QDialog):
    def __init__(self) -> None:
        super(InfoDialog, self).__init__()
        loadUi(db.resource_path('info_dialog.ui'), self)
        self.setWindowTitle("Informacion")
        #self.setFixedSize(570, 460)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowContextHelpButtonHint)
    
class Table(QTableWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def keyPressEvent(self, e):
        if (e.modifiers() & Qt.ControlModifier):
            selected = self.selectedRanges()

            if e.key() == Qt.Key_C: #copy
                s = "\t".join([str(self.horizontalHeaderItem(i).text()) for i in range(selected[0].leftColumn(), selected[0].rightColumn()+1)])
                s = s + '\n'

                for r in range(selected[0].topRow(), selected[0].bottomRow()+1):
                    for c in range(selected[0].leftColumn(), selected[0].rightColumn()+1):
                        try:
                            s += str(self.item(r,c).text()) + "\t"
                        except AttributeError:
                            s += "\t"
                    s = s[:-1] + "\n" #eliminate last '\t'
                QApplication.clipboard().setText(s)
                     
class DashWindow(QMainWindow):
    course_name = ""
    paralelo = ""

    @staticmethod
    def set_course_name(course):
        DashWindow.course_name = course

    @staticmethod
    def get_course_name():
        return DashWindow.course_name

    @staticmethod
    def set_evaluacion(evaluacion):
        DashWindow.evaluacion = evaluacion

    @staticmethod
    def get_evaluacion():
        return DashWindow.evaluacion

    @staticmethod
    def set_paralelo(paralelo):
        DashWindow.paralelo = paralelo

    @staticmethod
    def get_paralelo():
        return DashWindow.paralelo

    def __init__(self, course_name, paralelo, evaluacion):
        super().__init__()
        loadUi(db.resource_path('sideMenu.ui'), self)
        self.course_name = course_name
        self.set_course_name(course_name)
        self.paralelo = paralelo
        self.set_paralelo(self.paralelo)
        self.evaluacion = evaluacion
        self.set_evaluacion(evaluacion)
        # set the title of main DashWindow
        self.setWindowTitle('Teammates Data Plotter')
        
        # Dataframes usados
        self.dataframeHG = db.df_group_historic(self.course_name, self.paralelo) #Dataframe Historico entre Estudiantes
        self.dataframeHI = db.df_individual_historic(self.course_name, self.paralelo) #Dataframe Historico Individual
        self.dataframeIS = db.df_indiv_sesion(self.course_name, self.paralelo) #Dataframe Individual Sesión
        self.dataframeGS = db.df_group_sesion(self.course_name, self.paralelo) #Dataframe Grupal Sesión
        self.dataframeCI = db.df_score_sesion(self.course_name, self.paralelo) #Dataframe Calificacion individual 
        self.dataframeHE = db.df_team_historic(self.course_name, self.paralelo) #Dataframe Historico Equipo
        self.dataframeHP = db.df_group_historic_question(self.course_name, self.paralelo) #Dataframe Historico Grupal Preguntas
        # set the size of DashWindow
        self.Width = 900
        self.height = int(0.618 * self.Width)
        self.resize(self.Width, self.height)

        self.menuButton.clicked.connect(lambda: self.slideLeftMenu())
        self.homeButton.clicked.connect(lambda: self.home_button())
        self.indEvaluation.clicked.connect(lambda: self.ind_evaluation())
        self.indHistoric.clicked.connect(lambda: self.ind_historic())
        self.groupEvaluation.clicked.connect(lambda: self.group_evaluation())
        self.groupHistoric.clicked.connect(lambda: self.group_historic())
        self.gradesButton.clicked.connect(lambda: self.grades_button())
        self.teamsHistoric.clicked.connect(lambda: self.teams_button())
        self.groupQuestion.clicked.connect(lambda: self.group_question())
        self.uploadButton.clicked.connect(self.go_to_main)
        # add tabs
        self.tab7 = self.ui7()
        self.tab1 = self.ui1()
        self.tab3 = self.ui3()
        self.tab4 = self.ui4()
        self.tab5 = self.ui5()
        self.tab6 = self.ui6()
        self.tab8 = self.ui8()
        self.tab9 = self.ui9()


        #flags
        self.menuFlag = 0

        self.initUI()

    def go_to_main(self):
        HomeWindow.restart()
        
    def slideLeftMenu(self):
        width = self.slide_menu_container.width()
        if width==0:
            newWidth=240
            self.menuButton.setIcon(QIcon(db.resource_path(u"./icons/previous.png")))
        else:
            newWidth=0
            self.menuButton.setIcon(QIcon(db.resource_path(u"./icons/menu-button-of-three-horizontal-lines.png")))
        self.animation = QPropertyAnimation(self.slide_menu_container,b"maximumWidth")
        self.animation.setDuration(250)
        self.animation.setStartValue(width)
        self.animation.setEndValue(newWidth)
        self.animation.setEasingCurve(QEasingCurve.InOutQuart)
        self.animation.start()

    def initUI(self):


        self.right_widget.tabBar().setObjectName("mainTab")
        self.right_widget.addTab(self.tab7, '')
        self.right_widget.addTab(self.tab1, '')
        self.right_widget.addTab(self.tab3, '')
        self.right_widget.addTab(self.tab4, '')
        self.right_widget.addTab(self.tab5, '')
        self.right_widget.addTab(self.tab6, '')
        self.right_widget.addTab(self.tab8, '')
        self.right_widget.addTab(self.tab9, '')

        self.right_widget.setCurrentIndex(2)
        self.right_widget.setStyleSheet('''QTabBar::tab{width: 0;
            height: 0; margin: 0; padding: 0; border: none;}''')

    # buttons

    def home_button(self):
       self.right_widget.setCurrentIndex(2)
       self.headerTitle.setText("Inicio")

    def ind_evaluation(self):
        self.right_widget.setCurrentIndex(3)
        self.headerTitle.setText("Individual por evaluación")


    def ind_historic(self):
        self.right_widget.setCurrentIndex(4)
        self.headerTitle.setText("Individual Histórico")


    def group_evaluation(self):
        self.right_widget.setCurrentIndex(5)
        self.headerTitle.setText("Grupal por evaluación")


    def group_historic(self):
        self.right_widget.setCurrentIndex(7)
        self.headerTitle.setText("Histórico entre estudiantes")


    def grades_button(self):
        self.right_widget.setCurrentIndex(8)
        self.headerTitle.setText("Reporte de Calificaciones")


    def teams_button(self):
        self.right_widget.setCurrentIndex(6)
        self.headerTitle.setText("Histórico entre equipos")

    def group_question(self):
        self.right_widget.setCurrentIndex(9)
        self.headerTitle.setText("Histórico por Preguntas")



    # pages

    #UI Individual por sesión
    def ui1(self):
        self.fig_dict_IS = {}
        self.IS = loadUi(db.resource_path('individualSesion.ui'))
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")

        self.IS.comboSesionIS.addItems(get_all_evaluations(self.dataframeIS))
        self.IS.comboSesionIS.currentTextChanged.connect(lambda: self.add_all_figsIS(self.dataframeIS))
        
        self.IS.comboEquipoIS.addItems(get_all_teams(self.dataframeIS))
        self.IS.comboEquipoIS.currentTextChanged.connect(self.update_estudianteIS)
        
        self.IS.comboEstudianteIS.addItems(get_all_names_h(self.dataframeIS, str(self.IS.comboEquipoIS.currentText())))
        self.IS.btnFiltrarIS.clicked.connect(self.create_canvasIS)
        self.IS.btnExplicarIS.clicked.connect(self.showInformationIS)
        self.IS.btnExplicarIS.setToolTip("Informacion adicional") 
        self.IS.btnExportarIS.clicked.connect(self.guardarIS)

        self.add_all_figsIS(self.dataframeIS)
        key = 'E' + self.IS.comboSesionIS.currentText() + '-' + self.IS.comboEstudianteIS.currentText()
        self.addmplIS(self.fig_dict_IS[key])
        

        self.mainLayout.addWidget(self.IS.contentIS)
        main = QWidget()
        main.setLayout(self.mainLayout)
        return main




    # UI HISTORICO INDIVIDUAL
    def ui3(self):
        self.fig_dict_HI = {}
        self.HI = loadUi(db.resource_path('historicoIndividual.ui'))
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")
    
        self.HI.comboEquipoHI.addItems(get_all_teams(self.dataframeHI))
        self.HI.comboEquipoHI.currentTextChanged.connect(self.update_comboEstudianteHI)
                
        self.HI.comboEstudianteHI.addItems(get_all_names_h(self.dataframeHI, str(self.HI.comboEquipoHI.currentText())))
        self.HI.comboEstudianteHI.currentTextChanged.connect(self.cambiar_plot_HI)
      
        
        self.HI.btnExplicarHI.clicked.connect(self.showInformationHI)
        self.HI.btnExplicarHI.setToolTip("Informacion adicional") 

        self.HI.btnExportarHI.clicked.connect(self.guardarHI)

        self.add_all_figsHI(self.dataframeHI, str(self.HI.comboEquipoHI.currentText()))
        self.addmplHI(self.fig_dict_HI[get_all_names_h(self.dataframeHI, str(self.HI.comboEquipoHI.currentText()))[0]])
        
        self.mainLayout.addWidget(self.HI.contentHI)
        main = QWidget()
        main.setLayout(self.mainLayout)
        
        return main
    
    # UI Grupal por sesion    
    def ui4(self):
        self.fig_dict_GS = {}
        self.GS = loadUi(db.resource_path('grupalSesion.ui'))

        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")

        
        self.GS.btnExplicarGS.clicked.connect(self.showInformationGS)
        self.GS.btnExplicarGS.setToolTip("Informacion adicional") 

        self.GS.comboSesionGS.addItems(get_all_evaluations(self.dataframeGS))
        self.GS.comboSesionGS.currentTextChanged.connect(self.update_comboSesionGS)

        self.GS.comboEquipoGS.addItems(get_all_teams(self.dataframeGS))
        self.GS.comboEquipoGS.currentTextChanged.connect(self.cambiar_plot_GS)
        self.GS.btnExportarGS.clicked.connect(self.guardarGS)
        self.add_all_figsGS(self.dataframeGS, int(self.GS.comboSesionGS.currentText()))
        self.addmplGS(self.fig_dict_GS[get_all_teams(self.dataframeGS)[0]])

        self.mainLayout.addWidget(self.GS.contentGS)
        main = QWidget()
        main.setLayout(self.mainLayout)
        return main

    # UI HISTORICO EQUIPOS
    def ui5(self):
        self.HE = loadUi(db.resource_path('historicoEquipos.ui'))
        self.fig_dict_HE = {}
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")
        
       
        self.HE.btnExplicarHE.clicked.connect(self.showInformationHE)
        self.HE.btnExplicarHE.setToolTip("Informacion adicional") 
        
        for i in reversed(range(self.HE.vlCanvasHE.count())): 
            widgetToRemove = self.HE.vlCanvasHE.count().itemAt(i).widget()
            # remove it from the layout list
            self.HE.vlCanvasHE.count().removeWidget(widgetToRemove)
            # remove it from the gui
            widgetToRemove.setParent(None)
        figurilla = FigureCanvas(create_plot_he(self.dataframeHE))
        self.fig_dict_HE[0] = create_plot_he(self.dataframeHE)
        self.HE.vlCanvasHE.addWidget(figurilla)
        figurilla.draw()
        
        self.HE.btnExportarHE.clicked.connect(self.guardarHE)

        self.mainLayout.addWidget(self.HE.contentHE)
        main = QWidget()
        main.setLayout(self.mainLayout)
        return main
    
    # UI HISTORICO GRUPAL
    def ui6(self):

        self.fig_dict_HG = {}
        self.HG = loadUi(db.resource_path('historicoGrupal.ui'))
        
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")
        
       
        self.HG.btnExplicarHG.clicked.connect(self.showInformationHG)
        self.HG.btnExplicarHG.setToolTip("Informacion adicional") 
        
        self.HG.comboEquipoHG.addItems(get_all_teams(self.dataframeHG))
        self.HG.comboEquipoHG.currentTextChanged.connect(self.cambiar_plot_HG)
        self.HG.btnExportarHG.clicked.connect(self.guardarHG)
        self.add_all_figsHG(self.dataframeHG)
        self.addmplHG(self.fig_dict_HG[get_all_teams(self.dataframeHG)[0]])
        self.mainLayout.addWidget(self.HG.contentHG)
        main = QWidget()
        main.setLayout(self.mainLayout)
        return main

    def showInformationHG(self):
        titulo = "Informacion - Historico entre estudiantes"
        descripcion = "Creado con el objetivo de poder analizar y observar el rendimiento de los integrantes del equipo al transcurrir el tiempo"
        detalle = "Usando los componentes visuales acceda a los distintos grupos dentro del curso y analice cual es el mejor de todos"
        icono = db.resource_path("best-team.svg")
        dlg = InfoDialog()
        dlg.labelInfoDetalleT.setMinimumSize(QSize(0, 80))
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()
        
    def showInformationHP(self):
        titulo = "Informacion - Historico por preguntas"
        descripcion = "Creado con el objetivo de poder analizar y observar el rendimiento del equipo al transcurrir el tiempo usando como criterio las preguntas."
        detalle = ""
        i = 1
        for p in self.dataframeHP['Descripciones'].drop_duplicates():
            detalle += "P" + str(i)+ " - " + str(p) + ".\n"
            i+=1
        icono = db.resource_path("best-team.svg")
        dlg = InfoDialog()
        dlg.labelInfoDetalleT.setMinimumSize(QSize(0, 200))
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()
            
    def showInformationHE(self):
        titulo = "Informacion - Historico entre Equipos"
        descripcion = "Creado con el objetivo de poder analizar y comparar el rendimiento entre los equipos al transcurrir el tiempo"
        detalle = "Usando los componentes visuales analice cual es el mejor de todos"
        icono = db.resource_path("best-team.svg")
        dlg = InfoDialog()
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()  
              
    def showInformationHI(self):
        titulo = "Informacion - Historico Individual"
        descripcion = "Creado con el objetivo de poder analizar y observar el rendimiento de cada estudiante  al transcurrir el tiempo"
        detalle = "Usando los componentes visuales filtre mediante grupos para encontrar a un estudiante  dentro del curso y analice cual es el mejor de todos"
        icono = db.resource_path("best-ind.svg")
        dlg = InfoDialog()
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()
        
    def showInformationIS(self):
        titulo = "Informacion - Individual por sesion"
        descripcion = "Creado con el objetivo de poder analizar y observar el rendimiento de cada estudiante filtrando por sesiones"
        detalle = "Usando los componentes visuales filtre mediante grupos para encontrar a un estudiante dentro del curso y analice cual es el mejor de todos"
        icono = db.resource_path("best-ind.svg")
        dlg = InfoDialog()
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()
        
    def showInformationGS(self):
        titulo = "Informacion - Grupal por sesion"
        descripcion = "Creado con el objetivo de poder analizar y observar el rendimiento del equipo durante cada sesion existente"
        detalle = "Usando los componentes visuales acceda a los distintas sesiones de cada grupo dentro del curso y analice cual es el mejor de todos"
        icono = db.resource_path("best-team.svg")
        dlg = InfoDialog()
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()
        
    def showInformationCI(self):
        titulo = "Informacion - Reporte de calificaciones"
        descripcion = "Creado con el objetivo de poder otorgar mayor facilidad de calificacion a los profesores"
        detalle = "Usando los componentes visuales acceda a los distintas sesiones registradas dentro del curso y analice cada estudiante para su respectiva calificacion."
        icono = db.resource_path("calificacion.svg")
        dlg = InfoDialog()
        icon = QIcon()
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Normal, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Active, QIcon.On)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.Off)
        icon.addPixmap(QPixmap(icono), QIcon.Selected, QIcon.On)
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))
        dlg.imgInfo.setIcon(icon)
        dlg.imgInfo.setIconSize(QSize(124, 124))    
        dlg.labelInfoT.setText(titulo)
        dlg.labelT.setText(descripcion)
        dlg.labelInfoDetalleT.setText(detalle)
        dlg.exec()
        


    def guardarIS(self):
        response = QFileDialog.getSaveFileName(
            self,
            caption='Save Graphics to ...',
            directory=getcwd(),
            filter="PDF File (*.pdf);;PNG File (*.png);;JPG File (*.jpg)",
            initialFilter="PDF File (*.pdf)"
        )
        filename = response
        if filename[0] == '':
            # self.err_msg.setText('Un nombre para el archivo es requerido')
            #ocasiona un error al cer
            ("Un nombre para el archivo es requerido")
        if filename[1] == 'PDF File (*.pdf)' and filename[0][-4:] != '.pdf':
            filename = filename[0] + '.pdf'
        elif filename[1] == 'PNG File (*.png)' and filename[0][-4:] != '.png':
            filename = filename[0] + '.png'
        elif filename[1] == 'JPG File (*.jpg)' and filename[0][-4:] != '.jpg':
            filename = filename[0] + '.jpg'
        else:
            filename = filename[0]
        (filename)
        self.fig_dict_IS[self.IS.comboEstudianteIS.currentText()].savefig(filename)
        buttonReply = QMessageBox.information(self, 'Information', "El reporte ha sido exportado con exito", QMessageBox.Ok)


    def guardarGS(self):
        response = QFileDialog.getSaveFileName(
            self,
            caption='Save Graphics to ...',
            directory=getcwd(),
            filter="PDF File (*.pdf);;PNG File (*.png);;JPG File (*.jpg)",
            initialFilter="PDF File (*.pdf)"
        )
        filename = response
        if filename[0] == '':
            # self.err_msg.setText('Un nombre para el archivo es requerido')
            #ocasiona un error al cer
            ("Un nombre para el archivo es requerido")
        if filename[1] == 'PDF File (*.pdf)' and filename[0][-4:] != '.pdf':
            filename = filename[0] + '.pdf'
        elif filename[1] == 'PNG File (*.png)' and filename[0][-4:] != '.png':
            filename = filename[0] + '.png'
        elif filename[1] == 'JPG File (*.jpg)' and filename[0][-4:] != '.jpg':
            filename = filename[0] + '.jpg'
        else:
            filename = filename[0]
        (filename)
        self.fig_dict_GS[self.GS.comboEquipoGS.currentText()].savefig(filename)
        buttonReply = QMessageBox.information(self, 'Information', "El reporte ha sido exportado con exito", QMessageBox.Ok)

    def guardarHG(self):
        response = QFileDialog.getSaveFileName(
            self,
            caption='Save Graphics to ...',
            directory=getcwd(),
            filter="PDF File (*.pdf);;PNG File (*.png);;JPG File (*.jpg)",
            initialFilter="PDF File (*.pdf)"
        )
        filename = response
        if filename[0] == '':
            # self.err_msg.setText('Un nombre para el archivo es requerido')
            #ocasiona un error al cer
            ("Un nombre para el archivo es requerido")
        if filename[1] == 'PDF File (*.pdf)' and filename[0][-4:] != '.pdf':
            filename = filename[0] + '.pdf'
        elif filename[1] == 'PNG File (*.png)' and filename[0][-4:] != '.png':
            filename = filename[0] + '.png'
        elif filename[1] == 'JPG File (*.jpg)' and filename[0][-4:] != '.jpg':
            filename = filename[0] + '.jpg'
        else:
            filename = filename[0]
        self.fig_dict_HG[self.HG.comboEquipoHG.currentText()].savefig(filename)
        buttonReply = QMessageBox.information(self, 'Information', "El reporte ha sido exportado con exito", QMessageBox.Ok)

    def guardarHP(self):
        response = QFileDialog.getSaveFileName(
            self,
            caption='Save Graphics to ...',
            directory=getcwd(),
            filter="PDF File (*.pdf);;PNG File (*.png);;JPG File (*.jpg)",
            initialFilter="PDF File (*.pdf)"
        )
        filename = response
        if filename[0] == '':
            # self.err_msg.setText('Un nombre para el archivo es requerido')
            #ocasiona un error al cer
            ("Un nombre para el archivo es requerido")
        if filename[1] == 'PDF File (*.pdf)' and filename[0][-4:] != '.pdf':
            filename = filename[0] + '.pdf'
        elif filename[1] == 'PNG File (*.png)' and filename[0][-4:] != '.png':
            filename = filename[0] + '.png'
        elif filename[1] == 'JPG File (*.jpg)' and filename[0][-4:] != '.jpg':
            filename = filename[0] + '.jpg'
        else:
            filename = filename[0]
        self.fig_dict_HP[self.HP.comboEquipoHP.currentText()].savefig(filename)
        buttonReply = QMessageBox.information(self, 'Information', "El reporte ha sido exportado con exito", QMessageBox.Ok)
        
    def guardarHE(self):
        response = QFileDialog.getSaveFileName(
            self,
            caption='Save Graphics to ...',
            directory=getcwd(),
            filter="PDF File (*.pdf);;PNG File (*.png);;JPG File (*.jpg)",
            initialFilter="PDF File (*.pdf)"
        )
        filename = response
        if filename[0] == '':
            # self.err_msg.setText('Un nombre para el archivo es requerido')
            #ocasiona un error al cer
            ("Un nombre para el archivo es requerido")
        if filename[1] == 'PDF File (*.pdf)' and filename[0][-4:] != '.pdf':
            filename = filename[0] + '.pdf'
        elif filename[1] == 'PNG File (*.png)' and filename[0][-4:] != '.png':
            filename = filename[0] + '.png'
        elif filename[1] == 'JPG File (*.jpg)' and filename[0][-4:] != '.jpg':
            filename = filename[0] + '.jpg'
        else:
            filename = filename[0]
        (filename)
        self.fig_dict_HE[0].savefig(filename)
        buttonReply = QMessageBox.information(self, 'Information', "El reporte ha sido exportado con exito", QMessageBox.Ok)
        
    def guardarHI(self):
        response = QFileDialog.getSaveFileName(
            self,
            caption='Save Graphics to ...',
            directory=getcwd(),
            filter="PDF File (*.pdf);;PNG File (*.png);;JPG File (*.jpg)",
            initialFilter="PDF File (*.pdf)"
        )
        filename = response
        if filename[0] == '':
            # self.err_msg.setText('Un nombre para el archivo es requerido')
            #ocasiona un error al cer
            ("Un nombre para el archivo es requerido")
        if filename[1] == 'PDF File (*.pdf)' and filename[0][-4:] != '.pdf':
            filename = filename[0] + '.pdf'
        elif filename[1] == 'PNG File (*.png)' and filename[0][-4:] != '.png':
            filename = filename[0] + '.png'
        elif filename[1] == 'JPG File (*.jpg)' and filename[0][-4:] != '.jpg':
            filename = filename[0] + '.jpg'
        else:
            filename = filename[0]
        (filename)
        self.fig_dict_HI[self.HI.comboEstudianteHI.currentText()].savefig(filename)
        buttonReply = QMessageBox.information(self, 'Information', "El reporte ha sido exportado con exito", QMessageBox.Ok)


    def ui7(self):
        self.DASH = loadUi(db.resource_path('dashboard.ui'))
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")   
        
        self.DASH.tituloDashboard.setText("Bienvenido a " + self.course_name.upper() + " P" +str(self.paralelo))
        font = QFont()
        font.setFamily("Futura")
        font.setPointSize(16)
        self.DASH.tituloDashboard.setFont(font)
        self.DASH.tituloDashboard.setScaledContents(False)
        
        font = QFont()
        font.setFamily("Futura")
        font.setPointSize(14)
        self.DASH.GroupEquipos.setFont(font)
        
        # for loop
        x = 0
        y = 0
        for team in get_all_teams(self.dataframeHG):
            equipobox = self.createEquipoBox(team)
            if x==2:
                self.DASH.gridEquipos.addWidget(equipobox, x, y)
                x=0
                y+=1
            else:
                self.DASH.gridEquipos.addWidget(equipobox, x, y)
                x += 1
                        
        font = QFont()
        font.setFamily("Futura")
        font.setPointSize(14)
        self.DASH.GroupResumen.setFont(font)
        self.DASH.GroupResumen.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        
        for i in reversed(range(self.DASH.resumenes.count())): 
            widgetToRemove = self.DASH.resumenes.count().itemAt(i).widget()
            # remove it from the layout list
            self.DASH.resumenes.count().removeWidget(widgetToRemove)
            # remove it from the gui
            widgetToRemove.setParent(None)
        figurilla = FigureCanvas(create_plot_he(self.dataframeHE))
        plt.xlabel('')
        self.DASH.resumenes.addWidget(figurilla)
        figurilla.draw()        
        
        self.mainLayout.addWidget(self.DASH.contentDash)
        main = QWidget()
        main.setLayout(self.mainLayout)
        return main
    
    def createEquipoBox(self, equipoName):
        self.DASH.EquipoForm = QWidget(self.DASH.GroupEquipos)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        self.DASH.EquipoForm.setSizePolicy(sizePolicy)
        font = QFont()
        font.setFamily("Lucida Sans")
        self.DASH.EquipoForm.setFont(font)
        self.DASH.EquipoForm.setObjectName("EquipoForm")
        self.DASH.iconLayout = QHBoxLayout(self.DASH.EquipoForm)
        self.DASH.iconLayout.setContentsMargins(5, 5, 5, 5)
        self.DASH.iconLayout.setSpacing(2)
        self.DASH.iconLayout.setObjectName("iconLayout")
        # team y rating
        self.DASH.Equipo = QPushButton(self.DASH.EquipoForm)
        self.DASH.Equipo.setText(equipoName)
        self.DASH.Equipo.setObjectName("Equipo")
        css = '''QPushButton#Equipo{
            padding:2px;
            background-color:#40a2c4;
            border-radius:1px;
            color: white;
            margin-top:2px;
            border-style: outset;
            border-width: 2px;
            border-radius: 8px;
            border-color: beige;
            font: bold 10px;
            min-height: 2em;
            padding:10px;
            min-width:50px;
            }
            QPushButton#Equipo:Hover{
                background-color:#53d4ff;
            }
            QPushButton#Equipo:pressed{
                background-color:#388EAB;
            }
        '''
        self.DASH.Equipo.setStyleSheet(css)
        self.DASH.Equipo.setFlat(True)
        
        self.DASH.iconLayout.addWidget(self.DASH.Equipo)
        self.DASH.icons = QHBoxLayout()
        self.DASH.icons.setObjectName("icons")
        # for rating
        scoreL = db.get_avg_team(self.course_name, self.paralelo, equipoName)
        scoreList = list(scoreL)
        if scoreList:
            score = list(scoreL['Calificacion'])[0]

            if(round(score)>score):
                for i in range(int(round(score))):
                    pixmap = ""
                    if(i==round(score)-1):
                        pixmap = QPixmap(db.resource_path("halfstar.svg"))
                    else:
                        pixmap = QPixmap(db.resource_path("star.svg"))
                    self.DASH.iconstar = QPushButton(self.DASH.EquipoForm)
                    self.DASH.iconstar.setText("")
                    self.DASH.iconstar.setFlat(True)
                    self.DASH.iconstar.setObjectName("iconstar")
                    icon_star = QIcon(pixmap)
                    self.DASH.iconstar.setIcon(icon_star)
                    self.DASH.iconstar.setIconSize(QSize(10,10))
                    self.DASH.icons.addWidget(self.DASH.iconstar)
            else:
                for i in range(int(score)):
                    pixmap = QPixmap(db.resource_path("star.svg"))
                    self.DASH.iconstar = QPushButton(self.DASH.EquipoForm)
                    self.DASH.iconstar.setText("")
                    self.DASH.iconstar.setFlat(True)
                    self.DASH.iconstar.setObjectName("iconstar")
                    icon_star = QIcon(pixmap)
                    self.DASH.iconstar.setIcon(icon_star)
                    self.DASH.iconstar.setIconSize(QSize(10,10))
                    self.DASH.icons.addWidget(self.DASH.iconstar)
        
        self.DASH.iconLayout.addLayout(self.DASH.icons)
        return self.DASH.EquipoForm
    
    def ui8(self):
        self.fig_dict_CI = {}
        self.CI = loadUi(db.resource_path('calificaciones.ui'))
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")
        self.CI.comboEvaluacionCI.addItems(get_all_evaluations(self.dataframeCI))
        self.CI.comboEquipoCI.addItem("Todos")
        self.CI.comboEquipoCI.addItems(get_all_teams(self.dataframeCI))
        self.CI.btnFiltrarCI.clicked.connect(self.updateLista)
        
        self.CI.btnExplicarCI.clicked.connect(self.showInformationCI)
        self.CI.btnExplicarCI.setToolTip("Informacion adicional") 
        
        
        self.CI.tablaCalificacionesI = Table()
        self.CI.tablaCalificacionesI.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.CI.tablaCalificacionesI.setObjectName("tablaCalificacionesI")

        
        dataEvaluacion = self.dataframeCI.loc[self.dataframeCI['Evaluacion']==int(self.CI.comboEvaluacionCI.currentText()) , :]
        self.dataframeCI_Q7 = db.df_score_sesion_q7(self.course_name, self.paralelo)
        dataP7 = self.dataframeCI_Q7.loc[self.dataframeCI_Q7['Evaluacion']==int(self.CI.comboEvaluacionCI.currentText()) , :]
        
        preguntas= get_all_questions(self.dataframeCI)
        pregunta7= get_all_questions(dataP7)
        datagroup = dataEvaluacion
        equipos = True

        
        
        self.CI.tablaCalificacionesI.setHorizontalHeaderLabels(['Estudiante']+['Equipo']+preguntas+["Promedio"]+pregunta7)
        
        if str(self.CI.comboEquipoCI.currentText())!="Todos":
            datagroup = datagroup.loc[datagroup['Equipo']==str(self.CI.comboEquipoCI.currentText()), :]
            dataP7 = dataP7.loc[dataP7['Equipo']==str(self.CI.comboEquipoCI.currentText()), :]      
            info= datagroup.loc[:, datagroup.columns != 'Evaluacion']  
            lista = datagroup['Estudiante'].drop_duplicates().sort_values()
            estudiantes= array(lista,dtype=str)
            self.CI.tablaCalificacionesI.setColumnCount(3+len(preguntas))       
            self.CI.tablaCalificacionesI.setRowCount(len(estudiantes))
            self.CI.tablaCalificacionesI.setHorizontalHeaderLabels(['Estudiante']+preguntas+["Promedio"]+pregunta7)
            equipos = False
        else:
            dataP7 = self.dataframeCI_Q7.loc[self.dataframeCI_Q7['Evaluacion']==int(self.CI.comboEvaluacionCI.currentText()) , :]
            lista = datagroup['Estudiante'].drop_duplicates().sort_values()
            estudiantes= array(lista,dtype=str)
            self.CI.tablaCalificacionesI.setColumnCount(4+len(preguntas))       
            self.CI.tablaCalificacionesI.setRowCount(len(estudiantes))
            self.CI.tablaCalificacionesI.setHorizontalHeaderLabels(['Estudiante']+['Equipo']+preguntas+["Promedio"]+pregunta7)
            equipos = True 

        info= datagroup.loc[:, datagroup.columns != 'Evaluacion']
        lista = datagroup['Estudiante'].drop_duplicates().sort_values()
        
        estudiantes= array(lista,dtype=str)
        
        infoP7= dataP7.loc[:, dataP7.columns != 'Evaluacion']    

        for fila,estudiante in enumerate(estudiantes):
            informacionEstudiante= info.loc[info['Estudiante']==estudiante,: ]
            info7 = infoP7.loc[infoP7['Estudiante']==estudiante, :]
            self.CI.tablaCalificacionesI.setItem(fila, 0, QTableWidgetItem((str(estudiante))))
            index = 1
            if(equipos):
                index = 2
                apellido, nombre = estudiante.split(" ")
                estudiante = str(nombre) + " " + str(apellido)
                equipo = db.get_equipo_of_student(self.course_name, self.paralelo, estudiante)
                self.CI.tablaCalificacionesI.setItem(fila, 1, QTableWidgetItem((str(equipo))))
            calificaciones= informacionEstudiante['calificacion']
            calif7 = info7['calificacion']
            for columna,dato in enumerate(calificaciones):   
                item = QTableWidgetItem(str(dato))
                self.CI.tablaCalificacionesI.setItem(fila, index+columna, QTableWidgetItem((item)))
            promedio= calificaciones.mean()       
            itemm=QTableWidgetItem((str(round(promedio,2))))
            if promedio>=7.5:
                    itemm.setForeground(QBrush(QColor(0, 255, 0)))
            elif promedio<6:
                    itemm.setForeground(QBrush(QColor(255, 0, 0)))
            self.CI.tablaCalificacionesI.setItem(fila, index+1+columna, itemm)
            for columnita, dato in enumerate(calif7):
                item = QTableWidgetItem(str(dato))
                self.CI.tablaCalificacionesI.setItem(fila, index+2+columna, QTableWidgetItem((item)))
        
        self.CI.ContentCI.addWidget(self.CI.tablaCalificacionesI)
        self.mainLayout.addWidget(self.CI.contentCI)
        main = QWidget()
        main.setLayout(self.mainLayout)
        self.CI.tablaCalificacionesI.setSortingEnabled(True)

        return main
    
    def updateLista(self):
        self.CI.tablaCalificacionesI.clear()
        self.CI.tablaCalificacionesI.setSortingEnabled(False)

        dataEvaluacion = self.dataframeCI.loc[self.dataframeCI['Evaluacion']==int(self.CI.comboEvaluacionCI.currentText()) , :]
        self.dataframeCI_Q7 = db.df_score_sesion_q7(self.course_name, self.paralelo)
        dataP7 = self.dataframeCI_Q7.loc[self.dataframeCI_Q7['Evaluacion']==int(self.CI.comboEvaluacionCI.currentText()) , :]
        
        preguntas= get_all_questions(self.dataframeCI)
        pregunta7= get_all_questions(dataP7)
        datagroup = dataEvaluacion
        equipos = True

        
        
        self.CI.tablaCalificacionesI.setHorizontalHeaderLabels(['Estudiante']+['Equipo']+preguntas+["Promedio"]+pregunta7)
        
        if str(self.CI.comboEquipoCI.currentText())!="Todos":
            datagroup = datagroup.loc[datagroup['Equipo']==str(self.CI.comboEquipoCI.currentText()), :]
            dataP7 = dataP7.loc[dataP7['Equipo']==str(self.CI.comboEquipoCI.currentText()), :]      
            info= datagroup.loc[:, datagroup.columns != 'Evaluacion']  
            lista = datagroup['Estudiante'].drop_duplicates().sort_values()
            estudiantes= array(lista,dtype=str)
            self.CI.tablaCalificacionesI.setColumnCount(3+len(preguntas))       
            self.CI.tablaCalificacionesI.setRowCount(len(estudiantes))
            self.CI.tablaCalificacionesI.setHorizontalHeaderLabels(['Estudiante']+preguntas+["Promedio"]+pregunta7)
            equipos = False
        else:
            dataP7 = self.dataframeCI_Q7.loc[self.dataframeCI_Q7['Evaluacion']==int(self.CI.comboEvaluacionCI.currentText()) , :]
            lista = datagroup['Estudiante'].drop_duplicates().sort_values()
            estudiantes= array(lista,dtype=str)
            self.CI.tablaCalificacionesI.setColumnCount(4+len(preguntas))       
            self.CI.tablaCalificacionesI.setRowCount(len(estudiantes))
            self.CI.tablaCalificacionesI.setHorizontalHeaderLabels(['Estudiante']+['Equipo']+preguntas+["Promedio"]+pregunta7)
            equipos = True 

        info= datagroup.loc[:, datagroup.columns != 'Evaluacion']
        lista = datagroup['Estudiante'].drop_duplicates().sort_values()
        
        estudiantes= array(lista,dtype=str)
        
        infoP7= dataP7.loc[:, dataP7.columns != 'Evaluacion']    

        for fila,estudiante in enumerate(estudiantes):
            informacionEstudiante= info.loc[info['Estudiante']==estudiante,: ]
            info7 = infoP7.loc[infoP7['Estudiante']==estudiante, :]
            self.CI.tablaCalificacionesI.setItem(fila, 0, QTableWidgetItem((str(estudiante))))
            index = 1
            if(equipos):
                index = 2
                apellido, nombre = estudiante.split(" ")
                estudiante = str(nombre) + " " + str(apellido)
                equipo = db.get_equipo_of_student(self.course_name, self.paralelo, estudiante)
                self.CI.tablaCalificacionesI.setItem(fila, 1, QTableWidgetItem((str(equipo))))
            calificaciones= informacionEstudiante['calificacion']
            calif7 = info7['calificacion']
            for columna,dato in enumerate(calificaciones):   
                item = QTableWidgetItem(str(dato))
                self.CI.tablaCalificacionesI.setItem(fila, index+columna, QTableWidgetItem((item)))
            promedio= calificaciones.mean()       
            itemm=QTableWidgetItem((str(round(promedio,2))))
            if promedio>=7.5:
                    itemm.setForeground(QBrush(QColor(0, 255, 0)))
            elif promedio<6:
                    itemm.setForeground(QBrush(QColor(255, 0, 0)))
            self.CI.tablaCalificacionesI.setItem(fila, index+1+columna, itemm)
            for columnita, dato in enumerate(calif7):
                item = QTableWidgetItem(str(dato))
                self.CI.tablaCalificacionesI.setItem(fila, index+2+columna, QTableWidgetItem((item)))
        self.CI.tablaCalificacionesI.setSortingEnabled(True)

    def ui9(self):

        self.fig_dict_HP = {}
        self.HP = loadUi(db.resource_path('historicoPreguntas.ui'))
        
        self.mainLayout = QHBoxLayout(self.right_widget)
        self.mainLayout.setContentsMargins(0, 0, 0, 0)
        self.mainLayout.setSpacing(0)
        self.mainLayout.setObjectName("mainLayout")
        
       
        self.HP.btnExplicarHP.clicked.connect(self.showInformationHP)
        self.HP.btnExplicarHP.setToolTip("Informacion adicional") 
        
        self.HP.comboEquipoHP.addItems(get_all_teams(self.dataframeHP))
        self.HP.comboEquipoHP.currentTextChanged.connect(self.cambiar_plot_HP)
        self.HP.btnExportarHP.clicked.connect(self.guardarHP)
        self.add_all_figsHP(self.dataframeHP)
        self.addmplHP(self.fig_dict_HP[get_all_teams(self.dataframeHP)[0]])

        self.mainLayout.addWidget(self.HP.contentHP)
        main = QWidget()
        main.setLayout(self.mainLayout)
        return main
    
    
    def cambiar_plot_IS(self):
        self.rmmplIS()
        key = 'E' + self.IS.comboSesionIS.currentText() + '-' + self.IS.comboEstudianteIS.currentText()
        self.addmplIS(self.fig_dict_IS[key])
        self.IS.ContentIS.addWidget(self.IS.canvasIS)
            
    def rmmplIS(self):
        self.IS.vlCanvasIS.removeWidget(self.figurillaIS)


    def addmplIS(self, fig):
        figurilla = FigureCanvas(fig)
        self.figurillaIS = figurilla
        self.IS.vlCanvasIS.addWidget(self.figurillaIS)
        figurilla.draw()
                
    def cambiar_plot_HI(self, item):
        if item != '':
            student = item
            self.rmmplHI()
            self.addmplHI(self.fig_dict_HI[student])
            self.HI.ContentHI.addWidget(self.HI.canvasHI)

    def rmmplHI(self):
        self.HI.vlCanvasHI.removeWidget(self.figurillaHI)

    def addmplHI(self, fig):
        figurilla = FigureCanvas(fig)
        self.figurillaHI = figurilla
        
        self.HI.vlCanvasHI.addWidget(self.figurillaHI)
        figurilla.draw()

    def cambiar_plot_GS(self, item):
        if item != '':
            group = item
            self.rmmplGS()
            self.addmplGS(self.fig_dict_GS[group])
            self.GS.ContentGS.addWidget(self.GS.canvasGS)

    def rmmplGS(self):
        self.GS.vlCanvasGS.removeWidget(self.figurillaGS)

    def addmplGS(self, fig):
        figurilla = FigureCanvas(fig)
        self.figurillaGS = figurilla
        
        self.GS.vlCanvasGS.addWidget(self.figurillaGS)
        figurilla.draw()

    def cambiar_plot_HG(self, item):
        group = item
        self.rmmplHG()
        self.addmplHG(self.fig_dict_HG[group])
        self.HG.ContentHG.addWidget(self.HG.canvasHG)

    def rmmplHG(self):
        self.HG.vlCanvasHG.removeWidget(self.figurillaHG)
        #self.HG.canvasHG.close()

    def addmplHG(self, fig):
        figurilla = FigureCanvas(fig)
        self.figurillaHG = figurilla
        
        self.HG.vlCanvasHG.addWidget(self.figurillaHG)
        figurilla.draw()
        
    def cambiar_plot_HP(self, item):
        group = item
        self.rmmplHP()
        self.addmplHP(self.fig_dict_HP[group])
        self.HP.ContentHP.addWidget(self.HP.canvasHP)

    def rmmplHP(self):
        self.HP.vlCanvasHP.removeWidget(self.figurillaHP)
        #self.HP.canvasHP.close()

    def addmplHP(self, fig):
        figurilla = FigureCanvas(fig)
        self.figurillaHP = figurilla
        
        self.HP.vlCanvasHP.addWidget(self.figurillaHP)
        figurilla.draw()

    def add_all_figsIS(self, dataframe):
        evaluacion = self.IS.comboSesionIS.currentText()
        
        dataframe = dataframe.loc[dataframe["Evaluacion"]==int(evaluacion), :]
        for student in dataframe['Estudiante'].drop_duplicates():
            key = 'E' + evaluacion + '-' + student
            apellido, nombre = student.split(" ")
            estudiante = str(nombre) + " " + str(apellido)
            self.fig_dict_IS[key] = create_plot_is(dataframe, evaluacion, db.get_equipo_of_student(self.course_name, self.paralelo, estudiante), student)

    def add_all_figsGS(self, dataframe, evaluacion):
        for group in get_all_teams(dataframe):
            self.fig_dict_GS[group] = create_plot_gs(dataframe, evaluacion, group)
    def add_all_figsHI(self, dataframe, group):
        for student in get_all_names_h(dataframe, group):
            self.fig_dict_HI[student] = create_plot_hi(dataframe, group, student)
    
    def add_all_figsHG(self, dataframe):
        for group in get_all_teams(dataframe):
            self.fig_dict_HG[group] = create_plot_hg(dataframe, group)
            
    def add_all_figsHP(self, dataframe):
        for group in get_all_teams(dataframe):
            self.fig_dict_HP[group] = create_plot_hp(dataframe, group)         
    
    def update_comboEstudianteHI(self, item):
 
        group = str(item)
        self.fig_dict_HI = {}
        self.HI.comboEstudianteHI.clear()
        self.add_all_figsHI(self.dataframeHI, group)
        self.HI.comboEstudianteHI.addItems(get_all_names_h(self.dataframeHI, group))
        self.HI.comboEstudianteHI.currentTextChanged.connect(self.cambiar_plot_HI)
        
    def update_estudianteIS(self, item):
        group = str(item)
        evaluacion = int(self.IS.comboSesionIS.currentText())
        self.IS.comboEstudianteIS.clear()
        self.IS.comboEstudianteIS.addItems(get_all_names_h(self.dataframeIS, group))
        
    def create_canvasIS(self):
        self.cambiar_plot_IS()

    def update_comboSesionGS(self, item):
        group = str(item)
        self.fig_dict_GS = {}
        self.GS.comboEquipoGS.clear()
        self.add_all_figsGS(self.dataframeGS, int(self.GS.comboSesionGS.currentText()))
        self.GS.comboEquipoGS.addItems(get_all_teams(self.dataframeGS))
        self.GS.comboEquipoGS.currentTextChanged.connect(self.cambiar_plot_GS)  
            
#PLOT INDIVIDUAL POR SESION
def create_plot_is(dataframe, evaluacion, group, student):
    evaluacion = int(evaluacion)
    dataevaluacion = dataframe.loc[dataframe["Evaluacion"]==evaluacion, :]
    datagroup = dataevaluacion.loc[dataevaluacion["Equipo"]==group, :]
    dataindividual = datagroup.loc[datagroup["Estudiante"]==student, : ]
    barplot = catplot(x="Evaluacion", y="Calificacion", hue="Preguntas", data=dataindividual,
                          palette='hls', kind="bar")
    barplot.fig.suptitle("Informe Evaluacion " + str(evaluacion) + " - " + str(student) + '|' + str(group))
    barplot.fig.subplots_adjust(top=0.9)
    barplot.set(xlabel="Evaluaciones", ylabel="Promedio por Evaluacion")
    barplot.set(ylim=(0, 8.5))
    
    size_label=9
    # Anotaciones sobre cada barra.
    num_eva = len(dataindividual['Evaluacion'].drop_duplicates())
    x = []
    for n in range(len(dataindividual['Evaluacion'].drop_duplicates())):
        x.append(n)
    labels = []
    for d in x:
        numero = list(dataindividual['Evaluacion'].drop_duplicates())[d]
        labels.append('E'+ str(numero))
    for ax in barplot.axes.ravel():
        # add annotations
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        for p in ax.patches:
            ax.annotate(format(p.get_height(), '.1f'), 
                            (p.get_x() + p.get_width() / 2., p.get_height()), 
                            ha = 'center', va = 'center', 
                            size=size_label,
                            xytext = (0, -12), 
                            textcoords = 'offset points')
    return barplot.fig

#PLOT GRUPAL POR SESION
def create_plot_gs(dataframe, evaluacion, group):
    evaluacion = int(evaluacion)
    dataevaluation = dataframe.loc[dataframe["Evaluacion"]==evaluacion, :]
    datagroup = dataevaluation.loc[dataevaluation["Equipo"]==group, :]
    barplot = catplot(x = "Evaluacion", y = "calificacion", hue="Preguntas", data=datagroup,
                          palette="hls", kind="bar")
    barplot.fig.suptitle("Informe Evaluacion " + str(evaluacion) + " - " + str(group))
    barplot.fig.subplots_adjust(top=0.9)

    barplot.set(xlabel="Evaluaciones", ylabel="Promedio por Evaluacion")
    barplot.set(ylim=(0,8.5))
    
    size_label=9

    # Anotaciones sobre cada barra.
    num_eva = len(datagroup['Evaluacion'].drop_duplicates())
    x = []
    for n in range(len(datagroup['Evaluacion'].drop_duplicates())):
        x.append(n)
    labels = []
    for d in x:
        numero = list(datagroup['Evaluacion'].drop_duplicates())[d]
        labels.append('E'+ str(numero))
    for ax in barplot.axes.ravel():
        # add annotations
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        for p in ax.patches:
            ax.annotate(format(p.get_height(), '.1f'), 
                            (p.get_x() + p.get_width() / 2., p.get_height()), 
                            ha = 'center', va = 'center', 
                            size=size_label,
                            xytext = (0, -12), 
                            textcoords = 'offset points')
    return barplot.fig

# PLOT HISTORICO GRUPAL
def create_plot_hg(dataframe, group):
    datagroup = dataframe.loc[dataframe['Equipo']==group , :]
    barplot = ""
    
    if(len(datagroup['Evaluacion'].drop_duplicates()) > 1):
        barplot = relplot(x='Evaluacion', y='Calificacion', hue="Estudiante", 
                kind="line",ci=None,dashes=False, markers=True, data=datagroup, marker="o"
                )
        barplot.fig.suptitle("Informe Historico - " + str(group))
        barplot.fig.subplots_adjust(top=0.9)

        barplot.set(xlabel="Evaluaciones", ylabel="Promedio por Evaluacion")
        barplot.set(ylim=(0, 8.5))
            
        for ax in barplot.axes.flat:
            labels = ax.get_xticklabels()
            l = []
            x = []
            for label in labels:
                textito = int(label.get_text().split(".")[0])
                stringsito = "E" + str(textito)
                if(textito in list(dataframe['Evaluacion'].drop_duplicates()) and stringsito not in l):
                    l.append(stringsito)
                    x.append(textito)
            ax.set_xticks(x)
            ax.set_xticklabels(fontsize=10, labels=l)
    else:
        barplot = catplot(x = 'Evaluacion', y = 'Calificacion', hue="Estudiante", data = datagroup,
            palette = 'hls', kind='bar'
            )
        barplot.fig.suptitle("Informe Historico - " + str(group))
        barplot.fig.subplots_adjust(top=0.9)

        barplot.set(xlabel="Evaluaciones", ylabel="Promedio por Evaluacion")
        barplot.set(ylim=(0, 8.5))
        
        size_label=9
        # Anotaciones sobre cada barra.
        num_eva = len(datagroup['Evaluacion'].drop_duplicates())
        x = []
        for n in range(len(datagroup['Evaluacion'].drop_duplicates())):
            x.append(n)
        labels = []
        for d in x:
            numero = list(datagroup['Evaluacion'].drop_duplicates())[d]
            labels.append('E'+ str(numero))
        for ax in barplot.axes.ravel():
            # add annotations
            ax.set_xticks(x)
            ax.set_xticklabels(labels)
            for p in ax.patches:
                ax.annotate(format(p.get_height(), '.1f'), 
                                (p.get_x() + p.get_width() / 2., p.get_height()), 
                                ha = 'center', va = 'center', 
                                size=size_label,
                                xytext = (0, -12), 
                                textcoords = 'offset points')
    return barplot.fig

def create_plot_hp(dataframe, group):
    datagroup = dataframe.loc[dataframe['Equipo']==group , :]
    barplot = ""
    
    if(len(datagroup['Evaluacion'].drop_duplicates()) > 1):
        barplot = relplot(x='Evaluacion', y='Calificacion', hue="Preguntas", 
                kind="line",ci=None,dashes=False, markers=True, data=datagroup, marker="o"
                )
        barplot.fig.suptitle("Informe Historico - " + str(group))
        barplot.fig.subplots_adjust(top=0.9)
        barplot.set(xlabel="Evaluaciones", ylabel="Promedio por Evaluacion")
        barplot.set(ylim=(0, 8.5))
        
        for ax in barplot.axes.flat:
            labels = ax.get_xticklabels()
            l = []
            x = []
            for label in labels:
                textito = int(label.get_text().split(".")[0])
                stringsito = "E" + str(textito)
                if(textito in list(dataframe['Evaluacion'].drop_duplicates()) and stringsito not in l):
                    l.append(stringsito)
                    x.append(textito)
            ax.set_xticks(x)
            ax.set_xticklabels(fontsize=10, labels=l)
    else:
        barplot = catplot(x = 'Evaluacion', y = 'Calificacion', hue="Preguntas", data = datagroup,
            palette = 'hls', kind='bar'
            )
        barplot.fig.suptitle("Informe Historico - " + str(group))
        barplot.fig.subplots_adjust(top=0.9)
        barplot.set(ylim=(0, 8.5))
        barplot.set(ylabel="Promedio de equipo", xlabel="Evaluaciones")
        size_label=9
        
        # Anotaciones sobre cada barra.
        num_eva = len(datagroup['Evaluacion'].drop_duplicates())
        x = []
        for n in range(len(datagroup['Evaluacion'].drop_duplicates())):
            x.append(n)
        labels = []
        for d in x:
            numero = list(datagroup['Evaluacion'].drop_duplicates())[d]
            labels.append('E'+ str(numero))
        for ax in barplot.axes.ravel():
            # add annotations
            ax.set_xticks(x)
            ax.set_xticklabels(labels)
            for p in ax.patches:
                ax.annotate(format(p.get_height(), '.1f'), 
                                (p.get_x() + p.get_width() / 2., p.get_height()), 
                                ha = 'center', va = 'center', 
                                size=size_label,
                                xytext = (0, -12), 
                                textcoords = 'offset points')
    return barplot.fig

def create_plot_he(dataframe):
    barplot = ""
    if(len(dataframe['Evaluacion'].drop_duplicates()) > 1):
        barplot = relplot(x='Evaluacion', y='Calificacion', hue="Equipo", 
                kind="line",ci=None,dashes=False, markers=True, data=dataframe, marker="o"
                )
        barplot.fig.suptitle("Informe Historico entre equipos")
        barplot.fig.subplots_adjust(top=0.9)
        barplot.set(ylim=(0, 8.5))
        barplot.set(ylabel="Promedio de equipo", xlabel="Evaluaciones")
        
        for ax in barplot.axes.flat:
            labels = ax.get_xticklabels()
            l = []
            x = []
            for label in labels:
                textito = int(label.get_text().split(".")[0])
                stringsito = "E" + str(textito)
                if(textito in list(dataframe['Evaluacion'].drop_duplicates()) and stringsito not in l):
                    l.append(stringsito)
                    x.append(textito)
            ax.set_xticks(x)
            ax.set_xticklabels(fontsize=10, labels=l)
    else:
        barplot = catplot(x = 'Evaluacion', y = 'Calificacion', hue="Equipo", data = dataframe,
            palette = 'hls', kind='bar'
            )
        barplot.fig.suptitle("Informe Historico entre equipos")
        barplot.fig.subplots_adjust(top=0.9)
        barplot.set(ylabel="Promedio de equipo", xlabel="Evaluaciones")
        barplot.set(ylim=(0, 8.5))
        size_label=9
        
        # Anotaciones sobre cada barra.
        num_eva = len(dataframe['Evaluacion'].drop_duplicates())
        x = []
        for n in range(len(dataframe['Evaluacion'].drop_duplicates())):
            x.append(n)
        labels = []
        for d in x:
            numero = list(dataframe['Evaluacion'].drop_duplicates())[d]
            labels.append('E'+ str(numero))
        for ax in barplot.axes.ravel():
            # add annotations
            ax.set_xticks(x)
            ax.set_xticklabels(labels)
            for p in ax.patches:
                ax.annotate(format(p.get_height(), '.1f'), 
                                (p.get_x() + p.get_width() / 2., p.get_height()), 
                                ha = 'center', va = 'center', 
                                size=size_label,
                                xytext = (0, -12), 
                                textcoords = 'offset points')
    return barplot.fig

# PLOT HISTORICO INDIVIDUAL
def create_plot_hi(dataframe, group, estudiante):
    datagroup = dataframe.loc[dataframe['Equipo']==group , :]

    dataindividual =  datagroup.loc[datagroup['Estudiante']==estudiante , :] 

    barplot = ""
    
    if(len(dataindividual['Evaluacion'].drop_duplicates()) > 1):
        barplot = relplot(x='Evaluacion', y='Calificacion', hue="Estudiante", 
                kind="line",ci=None,dashes=False, markers=True, data=dataindividual, marker="o", legend=False
                )
        barplot.fig.suptitle("Informe Historico Individual - " + str(estudiante) + "|" + str(group))
        barplot.fig.subplots_adjust(top=0.9)
        barplot.set(ylabel="Promedio de equipo", xlabel="Evaluaciones")
        barplot.set(ylim=(0, 8.5))
        
        for ax in barplot.axes.flat:
            labels = ax.get_xticklabels()
            l = []
            x = []
            for label in labels:
                textito = int(label.get_text().split(".")[0])
                stringsito = "E" + str(textito)
                if(textito in list(dataframe['Evaluacion'].drop_duplicates()) and stringsito not in l):
                    l.append(stringsito)
                    x.append(textito)
            ax.set_xticks(x)
            ax.set_xticklabels(fontsize=10, labels=l)
    else:
        barplot = catplot(x = 'Evaluacion', y = 'Calificacion', hue="Estudiante", data = dataindividual,
            palette = 'hls', kind='bar', legend=False
            )
        barplot.set(ylabel="Promedio de equipo", xlabel="Evaluaciones")
        barplot.fig.suptitle("Informe Historico Individual - " + str(estudiante) + " | " + str(group))
        barplot.fig.subplots_adjust(top=0.9)
        barplot.set(ylim=(0, 8.5))
        size_label=9
        
        # Anotaciones sobre cada barra.
        num_eva = len(dataindividual['Evaluacion'].drop_duplicates())
        x = []
        for n in range(len(dataindividual['Evaluacion'].drop_duplicates())):
            x.append(n)
        labels = []
        for d in x:
            numero = list(dataindividual['Evaluacion'].drop_duplicates())[d]
            labels.append('E'+ str(numero))
        for ax in barplot.axes.ravel():
            # add annotations
            ax.set_xticks(x)
            ax.set_xticklabels(labels)
            for p in ax.patches:
                ax.annotate(format(p.get_height(), '.1f'), 
                                (p.get_x() + p.get_width() / 2., p.get_height()), 
                                ha = 'center', va = 'center', 
                                size=size_label,
                                xytext = (0, -12), 
                                textcoords = 'offset points')
    figure = barplot.fig
    
    return figure

def get_all_teams(dataframe):
    lista = dataframe['Equipo'].drop_duplicates().sort_values()
    return list(lista)

def get_all_names(dataframe):
    lista = dataframe['Estudiante'].drop_duplicates().sort_values()
    return lista
def get_all_names_h(dataframe, group):
    datagroup = dataframe.loc[dataframe['Equipo']==group , :]    
    lista = datagroup['Estudiante'].drop_duplicates().sort_values()

    return list(lista)
    
def get_all_evaluations(dataframe):
    lista = dataframe['Evaluacion'].drop_duplicates().sort_values()
    lista= array(lista,dtype=str)
    return list(lista)

def get_all_questions(dataframe):
    lista = dataframe['Preguntas'].drop_duplicates().sort_values()
    lista= array(lista,dtype=str)
    return list(lista)
