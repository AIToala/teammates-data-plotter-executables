# Teammates Data Plotter
Herramienta de visualización de datos de [TEAMMATES](https://teammatesv4.appspot.com/web/front/home)
![image](https://user-images.githubusercontent.com/19611806/133011532-eedfc536-d387-48fa-9b0d-7f900f111098.png)
![image](https://user-images.githubusercontent.com/19611806/133011574-6a0afb59-ea48-4e0a-8604-9a406b9acf95.png)

## Autores
* [Carlos Jimenez](https://github.com/CaJiFan)
* [Noelia Intriago](https://github.com/NoeliaIntriago)
* [Johan Gilces](https://github.com/jjgilces)
* [Francisco Villacis](https://github.com/franvillacis)
* [Andres Toala](https://github.com/AIToala)

## Funcionalidades
* Importe de archivos originarios de [Teammates](https://teammatesv4.appspot.com/web/front/home)  (.csv) para la anexacion de datos de cursos disponibles (IHC, Emprendimiento e Innovacion y ARP).
* Eliminacion de cursos registrados dentro de la aplicacion.
* Generar graficos exportables acorde a los datos obtenidos.
* Reporte de calificaciones.

## Como instalar?
Acceda al siguiente [repositorio](https://github.com/AIToala/teammates-data-plotter-executables) donde encontrara los archivos correspondientes a las versiones disponibles de descarga del proyecto listos para su uso sin necesidad de ninguna instalacion.

