from sqlite3 import Error, connect
import data.info as dataManager
import pandas as pd
from os import path
import sys
def error():
    return Error
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = path.abspath(".")

    return path.join(base_path, relative_path)
def create_connection():
    conn = None
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
    except Error as e:
        (e)

    return conn

conn = create_connection()
def create_db(conn):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor() # The database will be saved in the location where your 'py' file is saved
        #FOREIGN KEY (ref_num, ref_type) REFERENCES accounts
        #    (acc_num, acc_type)
        # Create table - Curso
        c.execute('PRAGMA foreign_keys=ON;') # IMPORTANTE PARA EL ON CASCADE
        c.execute('''CREATE TABLE IF NOT EXISTS Curso (
            nombreCurso VARCHAR(100),
            paralelo INT,
            PRIMARY KEY (nombreCurso, paralelo));''')
        # Create table - Evaluacion
        c.execute('''CREATE TABLE IF NOT EXISTS Evaluacion (
        idEvaluacion INT,
        codCurso VARCHAR(100),
        paralelo INT,
        PRIMARY KEY(idEvaluacion, codCurso, paralelo)
        CONSTRAINT fk_Evaluacion_Curso1
            FOREIGN KEY (codCurso, paralelo)
            REFERENCES Curso (nombreCurso, paralelo)
            ON DELETE CASCADE
        );''')
        # Index for table - Evaluacion
        c.execute('''CREATE INDEX IF NOT EXISTS fk_Evaluacion_Curso1_idx ON Evaluacion (codCurso);''')
        # Create table - Team
        c.execute('''CREATE TABLE IF NOT EXISTS Team (
            _idTeam INTEGER PRIMARY KEY,
            nombreTeam VARCHAR(45),
            codCurso VARCHAR(100),
            paralelo INT,
            CONSTRAINT fk_Team_Curso1
                FOREIGN KEY (codCurso, paralelo)
                REFERENCES Curso (nombreCurso, paralelo)
                ON DELETE CASCADE
        );''')
        # Index for table - Team
        c.execute('''CREATE INDEX IF NOT EXISTS fk_Team_Curso1_idx ON Team (codCurso);''')
        # Create table - Estudiante
        c.execute('''CREATE TABLE IF NOT EXISTS Estudiante (
            _idEstudiante INTEGER PRIMARY KEY  ,
            nombre VARCHAR(45) NOT NULL DEFAULT 'No name',
            apellido VARCHAR(45) NOT NULL DEFAULT 'No name',
            codTeam INTEGER,
            CONSTRAINT fkTeam
                FOREIGN KEY (codTeam)
                REFERENCES Team (_idTeam)
                ON DELETE CASCADE);''')
        # Index for table - Estudiante
        c.execute('''CREATE INDEX IF NOT EXISTS fkTeam_idx ON Estudiante (codTeam);''')
        
        # Create table - Pregunta
        c.execute('''CREATE TABLE IF NOT EXISTS Pregunta (
            _idPregunta INTEGER PRIMARY KEY,
            numeroPregunta INT NOT NULL,
            descripcion TEXT NOT NULL DEFAULT "No_description",
            valorMaximo INT NOT NULL DEFAULT 8,
            codEvaluacion INT,
            codCurso VARCHAR(100),
            paralelo INT,
            CONSTRAINT fk_Pregunta_Evaluacion1
                FOREIGN KEY (codEvaluacion, codCurso, paralelo)
                REFERENCES Evaluacion (idEvaluacion, codCurso, paralelo)
                ON DELETE CASCADE);''')
        # Index for table - Pregunta
        c.execute('''CREATE INDEX IF NOT EXISTS fk_Pregunta_Evaluacion1_idx ON Pregunta (codEvaluacion);''')
        # Create table - Respuesta
        c.execute('''CREATE TABLE IF NOT EXISTS Respuesta(
            codPregunta INT,
            codEstudiante INT,
            calificacion DECIMAL(4,2) NOT NULL default 0,
            PRIMARY KEY (codPregunta, codEstudiante),
            CONSTRAINT fkPregunta
                FOREIGN KEY (codPregunta)
                REFERENCES Pregunta (_idPregunta)
                ON DELETE CASCADE,
            CONSTRAINT fkEstudianteEva
                FOREIGN KEY (codEstudiante)
                REFERENCES Estudiante (_idEstudiante)
                ON DELETE CASCADE);''')
        # Index for table - Respuesta
        c.execute('''CREATE INDEX IF NOT EXISTS fkEstudianteEva_idx ON Respuesta (codEstudiante);''')
        
    except Error as err:
        print(err)
    finally:
        conn.commit()
        conn.close()
        
def get_all_teams(conn, curso, paralelo):
    try:
        c = conn.cursor() # The database will be saved in the location where your 'py' file is saved
        c.execute('''SELECT Team.nombreTeam from Curso 
                  inner join Team on curso.nombrecurso=Team.codCurso and curso.paralelo=Team.paralelo 
                  where curso.nombreCurso == ? and curso.paralelo=?;''',(curso,paralelo))
        rows = c.fetchall()
        return rows
    except Error as err:
        print(err)
    finally:
        conn.close()
def exists_curso(curso, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor() # The database will be saved in the location where your 'py' file is saved
        c.execute('''SELECT COUNT(*) from Curso where nombreCurso=? and paralelo=?''', (curso,paralelo))
        unico = int(str(c.fetchone()[0])) != 0
        return unico        
    except Error as err:
        print(err)
    finally:
        conn.close()
        
def exists_evaluacion(curso,paralelo, evaluacion):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor() # The database will be saved in the location where your 'py' file is saved
        c.execute('''SELECT COUNT(nombreCurso) from Curso 
                  inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                  where curso.nombreCurso=? and curso.paralelo=? and evaluacion.idEvaluacion=?''', (curso,paralelo, evaluacion))
        unico = int(str(c.fetchone()[0])) != 0
        return unico
    except Error as err:
        print(err)
    finally:
        conn.close()

def get_all_courses(conn):
    try:
        c = conn.cursor()
        c.execute('''SELECT nombreCurso, paralelo FROM Curso''')
        rows = c.fetchall()
        return rows
    except Error as err:
        print(err)
    finally:
        conn.close()

def delete_on_db_course(nombre_curso, paralelo):
    deleted = False
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('PRAGMA foreign_keys=ON;') # IMPORTANTE PARA EL ON CASCADE
        if(exists_curso(nombre_curso, paralelo)):
            c.execute('''DELETE FROM Curso WHERE nombreCurso=? and paralelo=?''', (nombre_curso, paralelo))
            deleted = True
        return deleted
    except Error as err:
        print(err)
        deleted=False
    finally:
        conn.commit()
        conn.close()

def delete_on_db_evaluacion(nombre_curso, paralelo):
    deleted = False
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('PRAGMA foreign_keys=ON;') # IMPORTANTE PARA EL ON CASCADE
        # if(exists_curso(nombre_curso, int(paralelo))):
        c.execute('''DELETE FROM Evaluacion WHERE codCurso=? and paralelo=?''', (nombre_curso, paralelo))
        deleted = True
        return deleted
    except Error as err:
        print(err)
        deleted=False
    finally:
        conn.commit()
        conn.close() 
        
def insert_on_db(nombre_curso, evaluacion, path_csv):
    inserted=False
    
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()  # The database will be saved in the location where your 'py' file is saved
        c.execute('PRAGMA foreign_keys=ON;') # IMPORTANTE PARA EL ON CASCADE
        #WE NEED THE PATH OF THE CSV ARCHIVE
        datos, paralelo, totalEstudiantes = dataManager.importar_datos(path_csv)
        #Insert table - Curso
        paralelo = int(paralelo.split(" ")[1])
        if(exists_curso(nombre_curso, paralelo) == False): 
            c.execute('''INSERT INTO Curso (nombreCurso, paralelo) values (?, ?)''',
                (nombre_curso,  int(paralelo)))            
        if(exists_evaluacion(nombre_curso, int(paralelo), evaluacion) == False):
            inserted=True
            #Insert table - Evaluacion
            c.execute('''INSERT INTO Evaluacion (idEvaluacion,codCurso, paralelo) values (?, ?, ?)''',
                    (evaluacion, nombre_curso, int(paralelo)))
            #Bucle para agregar data de Evaluacion
            teams = []
            for pregunta in datos.keys():
                for equipo in datos[pregunta]["Detalles"].keys():
                    # Insert table - Team
                    if(equipo not in teams):
                        teams.append(equipo)
            for team in teams:
                c.execute('''INSERT INTO Team (nombreTeam,codCurso,paralelo) values (?, ?, ?)''',
                                (team, nombre_curso, int(paralelo)))
            for pregunta in datos.keys():
                for equipo in datos[pregunta]["Detalles"].keys():
                    for estudiante in datos[pregunta]["Detalles"][equipo].keys():                        
                        info_estudiante = estudiante.split(" ")
                        nombre = info_estudiante[2]
                        apellido = info_estudiante[0]
                        #Insert table - Estudiante
                        c.execute('''SELECT _idTeam FROM Team where nombreTeam=? and codCurso=? and paralelo=? LIMIT 1;''', (equipo,nombre_curso,int(paralelo)))
                        cod_team = int(str(c.fetchone()[0]))
                        c.execute('''SELECT COUNT(*) from Estudiante where nombre=? and apellido=? and codTeam=?''', (nombre, apellido, cod_team))
                        unico = int(str(c.fetchone()[0])) == 0
                        if(unico):
                            c.execute('''INSERT INTO Estudiante (nombre,apellido,codTeam) values (?, ?, ?)''',
                                    (nombre, apellido, cod_team))
            for pregunta in datos.keys():
                # Insert table - Pregunta
                if pregunta == '7':
                    c.execute('''INSERT INTO Pregunta (numeroPregunta,descripcion,valorMaximo,codEvaluacion,codCurso,paralelo) values (?, ?, ?, ?, ?, ?)''',
                            (pregunta, datos[pregunta]["Descripcion"], 120, evaluacion, nombre_curso, int(paralelo)))
                else:
                    c.execute('''INSERT INTO Pregunta (numeroPregunta,descripcion,valorMaximo,codEvaluacion,codCurso,paralelo) values (?, ?, ?, ?, ?, ?)''',
                            (pregunta, datos[pregunta]["Descripcion"], 8, evaluacion, nombre_curso, int(paralelo)))
                
                for equipo in datos[pregunta]["Detalles"].keys():
                    for estudiante in datos[pregunta]["Detalles"][equipo].keys():
                        info_estudiante = estudiante.split(" ")
                        nombre = info_estudiante[2]
                        apellido = info_estudiante[0]
                        c.execute('''SELECT _idEstudiante FROM Estudiante where nombre=? and apellido=?  LIMIT 1;''', (nombre, apellido))
                        cod_estudiante = int(str(c.fetchone()[0]))
                        c.execute('''SELECT MAX(_idPregunta) FROM Pregunta LIMIT 1;''')
                        cod_pregunta = int(str(c.fetchone()[0]))
                    
                        # Insert table - Respuesta
                        c.execute('''INSERT INTO Respuesta (codPregunta, codEstudiante, calificacion) values (?, ?, ?)''',
                            (cod_pregunta, cod_estudiante, datos[pregunta]["Detalles"][equipo][estudiante]))
        return inserted
    except Error as err:
        print(err)
        inserted=False
    finally:
        conn.commit()
        conn.close()

def get_equipo_of_student(course, paralelo, student):
    nombre = student.split(" ")[0]
    apellido = student.split(" ")[1]
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('''SELECT team.nombreTeam from Curso 
                  inner join Team on curso.nombrecurso=Team.codCurso and curso.paralelo=Team.paralelo 
                  inner join Estudiante on Team._idTeam=Estudiante.codTeam 
                  where curso.nombreCurso=? and curso.paralelo=? and estudiante.nombre = ? and estudiante.apellido=?
                  limit 1''', (course,paralelo, nombre,apellido)) 
        rows = c.fetchone()
        if rows:
            return rows[0]
        else:
            return ""
    except Error as err:
        print(err)
        return 0
    finally:
        conn.close()

def get_paralelo(course):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()

        c.execute('''SELECT curso.paralelo from Curso 
                  inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                  where curso.nombreCurso=?
                  ORDER BY Curso.rowid DESC LIMIT 1''', (course,))
        paralelo = c.fetchone()
        if paralelo:
            return paralelo[0]
        else:
            return 0
    except Error as err:
        print(err)
        return 0
    finally:
        conn.close()

def get_total_evaluaciones(course, paralelo):
    unico = 0
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('''SELECT count(evaluacion.idEvaluacion) from Curso 
                  inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                  where curso.nombreCurso=? and curso.paralelo=?''', (course,paralelo))
        unico = int(str(c.fetchone()[0]))
        return unico
    except Error as err:
        print(err)
        return 0
    finally:
        conn.close()

def get_evaluaciones(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('''SELECT evaluacion.idEvaluacion from Curso 
                  inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                  where curso.nombreCurso=? AND curso.paralelo=?''', (course,paralelo))
        rows = c.fetchall()
        x = []
        for r in rows:
            x.append(r[0])    
        return x
    except Error as err:
        print(err)
        return []
    finally:
        conn.close()

def get_ultima_evaluacion(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('''SELECT evaluacion.idEvaluacion from Curso 
                  inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                  where curso.nombreCurso=? AND curso.paralelo=? limit 1;''', (course,paralelo))
        valor = int(str(c.fetchone()[0]))
        return valor
    except Error as err:
        print(err)
        return 0
    finally:
        conn.close()
        
def get_total_estudiantes(course, paralelo):
    unico = 0
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        c.execute('''SELECT count(estudiante._idEstudiante) from Curso 
                  inner join Team on curso.nombrecurso=Team.codCurso and curso.paralelo=team.paralelo
                    inner join Estudiante on Team._idTeam=Estudiante.codTeam 
                    where curso.nombreCurso=? AND curso.paralelo=?''', (course,paralelo))
        total = c.fetchone()
        if total:
            return total[0]
        else:
            return 0
    except Error as err:
        print(err)
        return 0
    finally:
        conn.close()
def get_maximum_calification(course, paralelo, evaluacion):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        c = conn.cursor()
        q = '''select
               round(avg(pregunta.valorMaximo),1) as Max_Calificacion
               from curso 
                inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
               inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
               where curso.nombreCurso="{}"
               and curso.paralelo="{}" 
               and evaluacion.idEvaluacion={};'''
        
        c.execute(q.format(course, paralelo, evaluacion))
        maximo = float(str(c.fetchone()[0]))
        return maximo
    except Error as err:
        (err)
        return False
    finally:
        conn.close()
def get_avg_team(course, paralelo, team):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''select Team.nombreteam as Equipo, 
                round(avg(respuesta.calificacion)/8*100,1)*5/100 as Calificacion
                from curso 
                inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
                inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
                inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join team on estudiante.codTeam = team._idTeam
                where curso.nombreCurso="{}"
                and curso.paralelo="{}" 
                and team.nombreTeam="{}"
                group by Equipo;'''
        
        query = conn.execute(q.format(course,paralelo, team))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
  
        return False
    finally:
        conn.close()

def df_indiv_sesion(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes

        q = '''SELECT Evaluacion.idEvaluacion as Evaluacion,
                estudiante.apellido || ' ' || estudiante.nombre  as Estudiante,
                "Pregunta " || Pregunta.numeropregunta AS Preguntas,
                Pregunta.descripcion AS Descripcion,
                round(avg(Respuesta.calificacion), 2) as Calificacion,
                Team.nombreteam as Equipo
                FROM Curso
                INNER JOIN Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                INNER JOIN Pregunta on Evaluacion.idEvaluacion = Pregunta.codEvaluacion
                INNER JOIN Respuesta ON Pregunta._idPregunta = Respuesta.codPregunta
                INNER JOIN Estudiante ON Respuesta.codEstudiante = Estudiante._idEstudiante
                inner join team on estudiante.codTeam = team._idTeam
                WHERE curso.nombrecurso = "{}"
                AND curso.paralelo = "{}"
                GROUP BY Evaluacion, Estudiante, Preguntas'''
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()

def df_score_sesion(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''SELECT 
                Evaluacion.idEvaluacion as Evaluacion,
                Team.nombreteam as Equipo,
                estudiante.apellido || ' ' || estudiante.nombre  as Estudiante,
                "Pregunta " || Pregunta.numeropregunta AS Preguntas,
                Pregunta.descripcion AS Descripciones,
                
                Respuesta.calificacion AS calificacion
                FROM Curso 
                inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
                inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
                inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join Team on estudiante.codTeam=Team._idTeam
                where curso.nombreCurso="{}"
                AND curso.paralelo="{}" and Preguntas != "Pregunta 7"
                group by evaluacion, estudiante, Preguntas ;'''
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()

def df_score_sesion_q7(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''SELECT 
                Evaluacion.idEvaluacion as Evaluacion,
                Team.nombreteam as Equipo,
                estudiante.apellido || ' ' || estudiante.nombre  as Estudiante,
                "Pregunta " || Pregunta.numeropregunta AS Preguntas,
                Pregunta.descripcion AS Descripciones,
                
                Respuesta.calificacion AS calificacion
                FROM Curso 
                inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
                inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
                inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join Team on estudiante.codTeam=Team._idTeam
                where curso.nombreCurso="{}"
                AND curso.paralelo="{}" and Preguntas = "Pregunta 7"
                group by evaluacion, estudiante, Preguntas ;'''
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()
        
def df_group_historic_question(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''SELECT 
                Evaluacion.idEvaluacion as Evaluacion,
                Team.nombreTeam as Equipo,
                "Pregunta " || Pregunta.numeropregunta AS Preguntas,
                Pregunta.descripcion AS Descripciones,
                round(avg(Respuesta.calificacion), 2) as Calificacion
                FROM Curso 
                inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
                inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
                inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join team on estudiante.codTeam = team._idTeam
                where curso.nombreCurso="{}"
                AND curso.paralelo="{}"
                group by evaluacion, equipo, Preguntas ;'''
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()
        
def df_group_sesion(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''SELECT Evaluacion.idEvaluacion as Evaluacion,
            "Pregunta" || Pregunta.numeropregunta AS Preguntas,
            Pregunta.descripcion AS Descripcion,
            round(avg(Respuesta.calificacion), 2) as calificacion,
            Team.nombreteam as Equipo
            FROM Curso
            inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
            INNER JOIN Pregunta on Evaluacion.idEvaluacion = Pregunta.codEvaluacion
            INNER JOIN Respuesta ON Pregunta._idPregunta = Respuesta.codPregunta
            INNER JOIN Estudiante ON Respuesta.codEstudiante = Estudiante._idEstudiante
            inner join team on estudiante.codTeam = team._idTeam
            WHERE curso.nombrecurso = "{}"
            AND curso.paralelo = "{}"
            GROUP BY Evaluacion, Equipo, Preguntas, Descripcion'''

        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()

def df_group_historic(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''select evaluacion.idevaluacion as Evaluacion, 
               Team.nombreteam as Equipo,
               estudiante.apellido || ' ' || estudiante.nombre  as Estudiante,
               round(avg(respuesta.calificacion),1) as Calificacion
               from curso 
               inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
               inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
               inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
               inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join team on estudiante.codTeam = team._idTeam
               where curso.nombreCurso="{}"
               and curso.paralelo="{}" and pregunta.numeroPregunta!="7"
               group by evaluacion, estudiante;'''
        
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()

# Historico Equipos
def df_team_historic(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''select evaluacion.idevaluacion as Evaluacion,
                Team.nombreteam as Equipo,
                round(avg(respuesta.calificacion),2) as Calificacion
                from curso 
                inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
                inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
                inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
                inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join team on estudiante.codTeam = team._idTeam
                where curso.nombreCurso="{}"
                and curso.paralelo="{}" and pregunta.numeroPregunta!="7"
                group by Evaluacion, Equipo;'''
        
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print("aqui")
        print(err)
        return False
    finally:
        conn.close()

def df_individual_historic(course, paralelo):
    try:
        conn = connect(resource_path('Teammates.db'))  # You can create a new database by changing the name within the quotes
        q = '''select evaluacion.idevaluacion as Evaluacion, 
               Team.nombreteam as Equipo, 
               estudiante.apellido || ' ' || estudiante.nombre  as Estudiante,
               round(avg(respuesta.calificacion),1) as Calificacion
               from curso 
               inner join Evaluacion on curso.nombrecurso=evaluacion.codCurso and curso.paralelo=evaluacion.paralelo 
               inner join pregunta on evaluacion.idEvaluacion=pregunta.codEvaluacion
               inner join respuesta on pregunta._idPregunta=Respuesta.codPregunta
               inner join estudiante on respuesta.codEstudiante = estudiante._idEstudiante
                inner join team on estudiante.codTeam = team._idTeam
               where curso.nombreCurso="{}"
               and curso.paralelo="{}" and pregunta.numeroPregunta!="7"
               group by evaluacion, estudiante;'''
        
        query = conn.execute(q.format(course, paralelo))
        cols = [column[0] for column in query.description]
        results = pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        return results
    except Error as err:
        print(err)
        return False
    finally:
        conn.close()