# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import QLabel, QStackedWidget,QVBoxLayout, QApplication, QFileDialog, QMainWindow, QDialog, QMessageBox, QPushButton, QWidget
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QIcon, QPixmap, QCursor
from PyQt5.uic import loadUi
import data.info as dataManager
import config, db
from os import getcwd
import dashboard as dash

def goto_dash(course, paralelo):
    graphics_window = dash.DashWindow(course, paralelo, db.get_evaluaciones(course, paralelo)[0])
    config.TeammatesPlotter.addWidget(graphics_window)
    config.global_index += 1
    config.TeammatesPlotter.setCurrentIndex(config.global_index)

def go_back():
    config.TeammatesPlotter.removeWidget(config.TeammatesPlotter.widget(config.global_index))
    config.global_index -= 1
    config.TeammatesPlotter.setCurrentIndex(config.global_index)


class HomeWindow(QMainWindow):
    course_name = ""
    @staticmethod
    def set_course_name(course):
        HomeWindow.course_name = course
    @staticmethod
    def get_course_name():
        return HomeWindow.course_name
    @staticmethod
    def restart():
        home_window = HomeWindow()
        for i in range(config.TeammatesPlotter.count()):
            widgetRemoving = config.TeammatesPlotter.currentWidget()
            config.TeammatesPlotter.removeWidget(widgetRemoving)
            widgetRemoving.setParent(None)
        config.TeammatesPlotter.addWidget(home_window)
        config.global_index = 0
        config.TeammatesPlotter.setCurrentIndex(config.global_index)
        
    def __init__(self) -> None:
        super(HomeWindow, self).__init__()
        loadUi(db.resource_path('designer.ui'), self)
        self.setWindowTitle("Teammates Data Plotter")
        self.new_file_btn.clicked.connect(self.goto_file_chooser)
        global conn
        conn = db.create_connection()
        db.create_db(conn)
        courses = db.get_all_courses(conn)
        if len(courses) > 0:
            # self.new_file_card.hide() #TODO
            for i, course in enumerate(courses):
                
                self.create_course_card(course[0], course[1],i+1)
        
    def goto_file_chooser(self):
        config.global_index += 1
        choose_file_window = ChooseFileWindow()
        config.TeammatesPlotter.addWidget(choose_file_window)

        config.TeammatesPlotter.setCurrentIndex(config.global_index)

    def create_course_card(self, course_name,paralelo, i):
        self.widget = QWidget(self.scrollArea)
        self.widget.setObjectName("course")
        self.widget.setMinimumSize(QSize(320, 300))
        self.widget.setMaximumSize(QSize(320, 300))
        self.widget.setStyleSheet('''QWidget#course{
            background-color: #fff;
            border-radius: 1px;
            border: 1px solid #ccc;}
            QWidget#course:hover{
            border: 1px solid #212121;}
            
            ''')
        
        self.verticalLayout_4 = QVBoxLayout(self.widget)
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        lbl_styles = "color:black;background-color:white; padding:0px 0px 0px 0px;"
        # Curso Label
        self.course_lbl = QLabel(self.widget)
        font = QFont()
        font.setFamily("Verdana")
        font.setPointSize(18)
        self.course_lbl.setFont(font)
        self.course_lbl.setStyleSheet(lbl_styles)
        self.course_lbl.setAlignment(Qt.AlignCenter)
        self.course_lbl.setObjectName("course_lbl")
        self.course_lbl.setText(course_name)
        self.verticalLayout_4.addWidget(self.course_lbl)

        # Paralelo lbl
        self.paralelo_lbl = QLabel(self.widget)
        self.paralelo_lbl.setFont(font)
        self.paralelo_lbl.setStyleSheet(lbl_styles)
        self.paralelo_lbl.setAlignment(Qt.AlignCenter)
        self.paralelo_lbl.setObjectName("paralelo_lbl")
        self.paralelo_lbl.setText('<b>Paralelo</b> '+str(paralelo))

        # Cantidad de evaluaciones lbl
        self.verticalLayout_4.addWidget(self.paralelo_lbl)
        self.evaluacion = QLabel(self.widget)
        self.evaluacion.setStyleSheet(lbl_styles)

        self.evaluacion.setAlignment(Qt.AlignCenter)
        self.evaluacion.setObjectName("evaluacion")
        self.evaluacion.setText("Evaluaciones registradas: "+ str(len(db.get_evaluaciones(course_name, paralelo))))
        self.verticalLayout_4.addWidget(self.evaluacion)

        self.btn_new_archive = QPushButton(self.widget)
        self.btn_new_archive.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_new_archive.setObjectName("btn_new_archive")
        self.btn_new_archive.setText("Nuevo archivo")
        self.btn_new_archive.setStyleSheet('''
            QPushButton#btn_new_archive{
            padding:10px;
            background-color:#40a2c4;
            border-radius:8px;
            color: white;
            margin-top:2px;}
            QPushButton#btn_new_archive:Hover{
                background-color:#53d4ff;
            }
            QPushButton#btn_new_archive:pressed{
                background-color:#40a2c4;
            }
        ''')
        self.btn_new_archive.clicked.connect(self.goto_file_chooser)

        self.btn_god = QPushButton(self.widget)
        self.btn_god.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_god.setText("Ingresar")
        self.set_course_name(course_name)
        self.btn_god.clicked.connect(lambda: goto_dash(course_name, paralelo))
        self.btn_god.setObjectName("btn_god")
        self.btn_god.setStyleSheet('''
            QPushButton#btn_god{
            padding:10px;
            background-color:#046bc4;
            color: white;
            margin-top:10px;
            border-width: 0px;
            border-radius:8px;
            font: bold 10px;
            }
            QPushButton#btn_god:Hover{
            background-color:#058fff;
            }
            QPushButton#btn_god:pressed{
                background-color:#40a2c4;
            }
        ''')


        self.btn_delete_course = QPushButton(self.widget)
        self.btn_delete_course.setCursor(QCursor(Qt.PointingHandCursor))
        self.btn_delete_course.setObjectName("btn_delete_course")
        self.btn_delete_course.setText("Eliminar Paralelo")
        self.btn_delete_course.setStyleSheet('''
            QPushButton#btn_delete_course{
            padding:10px;
            background-color:#d55e45;
            border-radius:8px;
            color: white;
            margin-top:2px;}
            QPushButton#btn_delete_course:Hover{
                background-color:#e85739;
            }
            QPushButton#btn_delete_course:pressed{
                background-color:#e85739;
            }
        ''')
        self.btn_delete_course.clicked.connect(lambda: self.showdialog(course_name, paralelo))
        self.verticalLayout_4.addWidget(self.btn_new_archive)
        self.verticalLayout_4.addWidget(self.btn_god)
        self.verticalLayout_4.addWidget(self.btn_delete_course)
        
        self.gridLayoutScrollArea.addWidget(self.widget, i//3, i%3, 1, 1)

    def showdialog(self, course_name, paralelo):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)

        msg.setText("¿Esta seguro que desea eliminar este paralelo?")
        msg.setInformativeText("Se eliminarán todas las evuaciones correspondientes")
        msg.setWindowTitle("Emininar {} Paralelo {}".format(course_name, paralelo))
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
            
        retval = msg.exec_()
        if retval == 1024:
            if(db.delete_on_db_course(course_name, paralelo)):
                sender = self.sender()
                parent = sender.parentWidget()
                self.gridLayoutScrollArea.removeWidget(parent)
                parent.setParent(None)
            else:
                print('error deleting')

class ChooseFileWindow(QDialog):
    def __init__(self) -> None:
        super(ChooseFileWindow, self).__init__()
        loadUi(db.resource_path('upload_file_window.ui'), self)
        self.select_file_btn.clicked.connect(self.getFileName)
        self.drag_drop_label.setText('Arrastra tu archivo aquí!')
        self.setAcceptDrops(True)
        self.backBtnUF.clicked.connect(go_back)
        self.setWindowTitle("Teammates Data Plotter")


    def getFileName(self):  
        file_filter = 'Tipo de archivos (*.xlsx *.csv *.dat)'
        response = QFileDialog.getOpenFileName(
            parent=self,
            caption='Seleccione un archivo',
            directory=getcwd(),
            filter=file_filter,
            initialFilter=file_filter
        )

        self.selected_file = response[0]
        
        self.filename_label.setText(self.selected_file)
        if self.selected_file:
            self.import_file_btn.setStyleSheet('''
            background-color:#0577a8;
            color: white;
            border-color: beige;
            padding:10px;
            border-radius:6px;
            font: bold 14px;
            ''')
            self.import_file_btn.clicked.connect(self.goto_extra_data)
            pixmap = QPixmap(db.resource_path('csv.svg'))
            pixmap = pixmap.scaled(128, 128, Qt.KeepAspectRatio)
            self.drag_drop_label.setAlignment(Qt.AlignCenter)
            self.drag_drop_label.setPixmap(pixmap)
            self.import_file_btn.setCursor(QCursor(Qt.PointingHandCursor))
        else:
            self.import_file_btn.setCursor(QCursor(Qt.ForbiddenCursor))
            self.import_file_btn.setStyleSheet('''
            padding:10px;
            background-color: grey;
            border-radius:6px;
            color: white;
            font: bold 14px;''')

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            event.setDropAction(Qt.CopyAction)
            self.selected_file = event.mimeData().urls()[0].toLocalFile()
            self.filename_label.setText(self.selected_file)
            pixmap = QPixmap(db.resource_path('csv.svg'))
            pixmap = pixmap.scaled(128, 128, Qt.KeepAspectRatio)
            self.drag_drop_label.setAlignment(Qt.AlignCenter)
            self.drag_drop_label.setPixmap(pixmap)
            event.accept()
            self.import_file_btn.setStyleSheet('''
            padding:12px 10px;
            border-radius:1px;
            color: white;
            background-color : navy''')
            self.import_file_btn.setCursor(QCursor(Qt.PointingHandCursor))
            self.import_file_btn.clicked.connect(self.goto_extra_data)
        else:
            event.ignore()

    def goto_extra_data(self):
        config.global_index += 1
        extra_data_window = ExtraDataForm(self.selected_file)
        config.TeammatesPlotter.addWidget(extra_data_window)        
        config.TeammatesPlotter.setCurrentIndex(config.global_index)

    
class ExtraDataForm(QDialog):
    def __init__(self, selected_file) -> None:
        super(ExtraDataForm, self).__init__()
        loadUi(db.resource_path('extra_data.ui'), self)
        self.setWindowTitle("Teammates Data Plotter")
        self.insert_btn.clicked.connect(self.goto_confirm_window)
        self.backBtnED.clicked.connect(go_back)
        self.selected_file = selected_file

    def goto_confirm_window(self):
        course = self.input_course.currentText()
        numEvaluacion = self.input_eva.text()
        period= self.period.currentText()
        subject= course+"-"+period
        subject=subject.upper()

        if course and numEvaluacion and self.selected_file:
            config.global_index += 1
            confirm_window = ConfirmWindow(subject, numEvaluacion, self.selected_file)
            config.TeammatesPlotter.addWidget(confirm_window)
            config.TeammatesPlotter.setCurrentIndex(config.global_index)
                
        else:
            buttonReply = QMessageBox.warning(self, 'Error', "Los campos son requeridos", QMessageBox.Ok)

class ConfirmWindow(QDialog):
    def __init__(self, course, numEvaluacion, selected_file) -> None:
        super(ConfirmWindow, self).__init__()
        loadUi(db.resource_path('confirm_dialog.ui'), self)
        self.setWindowTitle("Teammates Data Plotter")
        self.accept_btn.clicked.connect(self.goto_dashboard)
        self.cancel_btn.clicked.connect(go_back)
        self.course = course
        self.numEvaluacion = numEvaluacion
        self.selected_file = selected_file
        self.paralelo_db = db.get_paralelo(course)
        _, self.paralelo_db, totalEstudiantes = dataManager.importar_datos(self.selected_file)
        self.paralelo_db = int(self.paralelo_db.split(" ")[1])
        self.total_estudiantes = totalEstudiantes
        self.course_lbl.setText(self.course_lbl.text() +" "+ self.course)
        self.eva_lbl.setText(self.eva_lbl.text() +" "+ str(self.numEvaluacion))

        if self.paralelo_db != 0:
            self.paralelo.setText(self.paralelo.text()+" "+str(self.paralelo_db))

        if self.total_estudiantes > 0:
            self.students.setText(self.students.text()+" "+str(self.total_estudiantes))
        else:
            self.students.setText(self.students.text()+" "+ "0")

    def goto_dashboard(self):
        if db.insert_on_db(self.course, self.numEvaluacion, self.selected_file):
            config.global_index += 1
            graphics_window = dash.DashWindow(self.course, self.paralelo_db, self.numEvaluacion)
            config.TeammatesPlotter.addWidget(graphics_window)
            config.TeammatesPlotter.setCurrentIndex(config.global_index)
        else:
            buttonReply = QMessageBox.warning(self, 'Error', "La evaluación ya se encuentra registrado", QMessageBox.Ok)

if __name__ == "__main__":
    from sys import exit
    app = config.app
    pixmap = QPixmap(db.resource_path("b.svg"))
    ico = QIcon(pixmap)
    app.setWindowIcon(ico)
    config.TeammatesPlotter.setWindowTitle("Teammates Data Plotter")
    conn = db.create_connection()
    home_window = HomeWindow()
    config.TeammatesPlotter.addWidget(home_window)
    config.TeammatesPlotter.show()
    selected_file = None
    exit(app.exec_())